# Install & Distribute the “Scan to MyApp” Shortcut

Shortcut must be installed once per device. Either:
- Build it on-device using `scan-to-myapp.steps.md` (no signing), or
- Sign the skeleton on a Mac (Shortcuts CLI) to produce `.shortcut`, then host or AirDrop it.
