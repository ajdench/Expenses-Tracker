# Scan-to-PWA via Shortcuts – Workflow & Implementation Guide

Goal: From your PWA, open a named Shortcut that launches **Scan Documents**, auto‑names the PDF as
`<vendor>-<date>-<time>-<currency>-<value>.pdf`, saves to **On My iPhone › MyApp › Scans**, and returns to your PWA to import.
