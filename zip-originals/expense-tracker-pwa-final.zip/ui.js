// Renders trips and expenses
async function renderTrips() {
  const trips = await getAllTrips();
  const app = document.getElementById('app');
  trips.forEach(trip => {
    const div = document.createElement('div');
    div.textContent = trip.name + ' (' + trip.status + ')';
    div.className = 'p-2 border-b';
    app.appendChild(div);
  });
}
