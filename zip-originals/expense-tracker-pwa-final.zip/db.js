// IndexedDB abstraction using idb
let db;

async function initDB() {
  db = await idb.openDB('ExpenseTracker', 1, {
    upgrade(db) {
      db.createObjectStore('trips', { keyPath: 'id' });
      db.createObjectStore('expenses', { keyPath: 'id' });
    }
  });
}

async function saveTrip(trip) {
  return db.put('trips', trip);
}

async function saveExpense(expense) {
  return db.put('expenses', expense);
}

async function getAllTrips() {
  return db.getAll('trips');
}

async function getAllExpenses() {
  return db.getAll('expenses');
}
